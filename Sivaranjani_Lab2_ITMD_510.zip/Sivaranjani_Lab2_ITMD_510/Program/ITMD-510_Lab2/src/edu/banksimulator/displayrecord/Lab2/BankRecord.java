package edu.banksimulator.displayrecord.Lab2;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

/**
 * This class is used to read a file that contains the bank records and print
 * all the data in a readable format
 * 
 * @author Sivaranjani
 *
 */
public class BankRecord extends Client {

	static Scanner SCANNER = new Scanner(System.in);

	/**
	 * Constant variables for formatting display
	 */
	static String DOUBLE_LINE = "=================================================================================================================================================================";
	static String SINGLE_LINE = "-----------------------------------------------------------------------------------------------------------------------------------------------------------------";
	static String DASH_LINE = "|";

	/**
	 * The fields of BankRecord
	 */
	private String id, sex, region, married, car, save_Act, current_Act, mortgage, pep;
	private int age, children;
	private double income;

	static ArrayList<List<String>> records = new ArrayList<>();
	private static BankRecord record[] = new BankRecord[700];

	/**
	 * This is the method to read Banking Record from CSV file
	 */
	public void readData() throws IOException {

		System.out.println("Please Enter name of CSV File to load data. E.g: bank-detail");
		String fileName = String.valueOf(SCANNER.next());

		/*
		 * Check if user has entered empty or invalid file name
		 */
		if (fileName.isEmpty()) {
			throw new IllegalArgumentException("File name shouldnot be empty");
		}
		while (fileName.contains(".") || fileName.contains("?") || fileName.contains("<") || fileName.contains(">")
				|| fileName.contains("/") || fileName.contains("\\") || fileName.contains("|") || fileName.contains(":")
				|| fileName.contains("\"") || fileName.contains("*")) {

			System.out.println("Enter valid CSV file without any extension");
			fileName = String.valueOf(SCANNER.next());
		}

		/*
		 * Try Catch block to check if user has entered file not present in respective
		 * location
		 */
		BufferedReader br = null;
		try {
			br = new BufferedReader(new FileReader(new File(fileName + ".csv")));
		} catch (Exception e) {
			System.out.println("The requested FILE NOT FOUND in : " + System.getProperty("user.dir"));
			readData();
			return;
		}

		/*
		 * Clearing memory of array before entering data - To avoid array index out of
		 * bound
		 */
		String line = null;
		if (br != null) {
			// Reading comma separated file
			while ((line = br.readLine()) != null) {
				records.add(Arrays.asList(line.split(",")));
			}
		}
		processData();
		br.close();
	}

	/**
	 * This is the method to process Banking Record and store in array list
	 */
	public void processData() {

		int index = 0;
		/*
		 * Fetching data from CSV file and loading in array list
		 */
		for (List<String> rowData : records) {
			record[index] = new BankRecord();
			record[index].setId(rowData.get(0));
			record[index].setAge(Integer.parseInt(rowData.get(1)));
			record[index].setSex(rowData.get(2));
			record[index].setRegion(rowData.get(3));
			record[index].setIncome(Double.parseDouble(rowData.get(4)));
			record[index].setMarried(rowData.get(5));
			record[index].setChildren((Integer.parseInt(rowData.get(6))));
			record[index].setCar(rowData.get(7));
			record[index].setSave_Act(rowData.get(8));
			record[index].setCurrent_Act(rowData.get(9));
			record[index].setMortgage(rowData.get(10));
			record[index].setPep(rowData.get(11));
			index++;
		}
		printData();
	}

	/**
	 * This is the method to display requested no.of. Banking Records from array
	 * list
	 */
	public void printData() {

		int requestedRows = 0;

		System.out.println("Data loaded from the given file !!!....");

		/*
		 * The requested row count should not be more than the number of records in the
		 * file and less than 1
		 */
		while (requestedRows > records.size() || requestedRows < 1) {

			System.out.printf("Total.No.of.Rows in file : %d. \n", records.size());
			System.out.println("Please Enter valid No.of.rows to be printed");
			try {
				requestedRows = Integer.valueOf(SCANNER.next());
			} catch (NumberFormatException e) {
				System.out.println("Enter valid no.of.rows");
				requestedRows = 0;
			}
		}

		/*
		 * Printing data from CSV file in readable format
		 */
		System.out.println(DOUBLE_LINE);
		System.out.print(DASH_LINE);
		System.out.print(
				"ID \t\t AGE \t SEX   \t REGION	    INCOME \tMARRIAGE \tCHILDREN \tCAR \t SAVINGS\tCURRENT  \tMORTGAGE\tPEP	");
		System.out.println("  \t" + DASH_LINE);
		System.out.println(DOUBLE_LINE);

		for (int index = 0; index < requestedRows; index++) {

			System.out.print(DASH_LINE);
			System.out.printf(
					"%s\t %d\t %s\t %-10.30s %.2f\t %s	\t  %d \t\t%-10.30s %-10.30s\t %-10.30s\t %-10.30s\t %-10.30s",
					record[index].getId(), record[index].getAge(), record[index].getSex(), record[index].getRegion(),
					record[index].getIncome(), record[index].getMarried(), record[index].getChildren(),
					record[index].getCar(), record[index].getSave_Act(), record[index].getCurrent_Act(),
					record[index].getMortgage(), record[index].getPep());
			System.out.println("  \t" + DASH_LINE);

			if (!(requestedRows == index + 1))
				System.out.println("\n" + SINGLE_LINE);
		}
		System.out.println("\n" + DOUBLE_LINE);
	}

	/**
	 * Following are the getters and setters of the BankRecord fields
	 */
	public String getId() {
		return id;
	}

	public void setId(String string) {
		this.id = string;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String string) {
		this.sex = string;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getMarried() {
		return married;
	}

	public void setMarried(String married) {
		this.married = married;
	}

	public String getCar() {
		return car;
	}

	public void setCar(String car) {
		this.car = car;
	}

	public String getSave_Act() {
		return save_Act;
	}

	public void setSave_Act(String save_Act) {
		this.save_Act = save_Act;
	}

	public String getCurrent_Act() {
		return current_Act;
	}

	public void setCurrent_Act(String current_Act) {
		this.current_Act = current_Act;
	}

	public String getMortgage() {
		return mortgage;
	}

	public void setMortgage(String mortgage) {
		this.mortgage = mortgage;
	}

	public String getPep() {
		return pep;
	}

	public void setPep(String pep) {
		this.pep = pep;
	}

	public int getChildren() {
		return children;
	}

	public void setChildren(int children) {
		this.children = children;
	}

	public double getIncome() {
		return income;
	}

	public void setIncome(double income) {
		this.income = income;
	}
}
