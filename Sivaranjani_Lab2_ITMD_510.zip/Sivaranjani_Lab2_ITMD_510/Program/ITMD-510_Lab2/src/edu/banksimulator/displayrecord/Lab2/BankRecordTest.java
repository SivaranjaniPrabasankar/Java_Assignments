package edu.banksimulator.displayrecord.Lab2;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 * This class is used to test the BankRecord application
 * 
 * @author Sivaranjani
 *
 */
public class BankRecordTest {

	/**
	 * This is the main method to run and test this Banking Record Display
	 * application
	 */
	public static void main(String[] args) throws IOException {

		BankRecord record = new BankRecord();
		int choice = 0;
		System.out.println(BankRecord.DOUBLE_LINE);
		System.out.println("Welcome to IIT BANK Record Display");
		System.out.println(BankRecord.DOUBLE_LINE);
		
		do {
			System.out.println("Want to read bank data? Please Press \n 1. Display CSV file \n 2. Exit application");
			try {
				choice = Integer.valueOf(BankRecord.SCANNER.next());
			} catch (NumberFormatException e) {
				System.out.print("You have entered an invalid option. \t");
			}
		
			switch (choice) {
			case 1: {
				record.readData();
				choice = 0;
				BankRecord.records.clear();
				break;
			}
			case 2: {
				System.out.println("Thank You for using our Application");
				String timeStamp = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime());
				System.out.println("Date and Time :" + timeStamp + "\nProgrammed by Sivaranjani A20436206 \n");
				System.exit(0);
			}
			default:
				choice = 0;
				System.out.println("Please choose from given choice.");
				break;
			}
		} while (choice == 0);
	}
}
