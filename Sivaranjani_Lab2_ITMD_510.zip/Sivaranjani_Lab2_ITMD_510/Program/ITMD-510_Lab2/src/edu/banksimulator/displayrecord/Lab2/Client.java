package edu.banksimulator.displayrecord.Lab2;

import java.io.IOException;

/**
 * @author Sivaranjani
 *
 */

/**
 * This is the abstract class contain three abstract methods
 */
public abstract class Client {

	public abstract void readData() throws IOException;

	public abstract void processData();

	public abstract void printData();

}