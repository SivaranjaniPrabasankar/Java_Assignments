package records;

public class FemaleComparator {
	public int compare(BankRecord o1, BankRecord o2) {
		// TODO Auto-generated method stub
		int result = o1.getSex().compareTo(o2.getSex());
		return result;

	}
}
