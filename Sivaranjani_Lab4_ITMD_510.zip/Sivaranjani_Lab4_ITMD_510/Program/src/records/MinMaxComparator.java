package records;

public class MinMaxComparator {
	public int compare(BankRecord o1, BankRecord o2) {

		int result = Double.toString(o1.getIncome()).compareTo(Double.toString(o2.getIncome()));
		return result;
	}
}
