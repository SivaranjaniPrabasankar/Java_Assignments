package records;

public class LocationComparator {
	public int compare(BankRecord o1, BankRecord o2) {
		// use compareTo to compare strings
		int result = o1.getRegion().compareTo(o2.getRegion());
		return result;
	}

}
