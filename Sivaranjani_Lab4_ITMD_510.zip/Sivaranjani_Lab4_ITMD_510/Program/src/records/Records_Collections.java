package records;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Records_Collections extends BankRecord {

	public void filterByRegion(List<BankRecord> dataList) throws IOException {

		String fileContent = null;
		Map<String, List<BankRecord>> recordsByRegion = dataList.stream()
				.collect(Collectors.groupingBy(BankRecord::getRegion));
		BufferedWriter writer = new BufferedWriter(new FileWriter("bankrecords_Sivaranjani.txt"));
		// new FileWriter("D:/Spring-19/For Submission/OOPS Lab 3/bankrecords.txt"));

		System.out.println("  \n" + doubleLine);
		System.out.printf("Data Analytics for %s regions \n", recordsByRegion.size());
		for (String key : recordsByRegion.keySet()) {
			List<BankRecord> bankRecordsByregion = recordsByRegion.get(key);

			/* Creating a list for income based on location */

			List<Double> incomeList = bankRecordsByregion.stream().map(record -> record.getIncome())
					.collect(Collectors.toList());

			double sum = incomeList.stream().mapToDouble(i -> i).sum();
			double average = sum / incomeList.size();

			/*
			 * Creating a list of females with both a mortgage and savings account based on
			 * location
			 */

			Stream<BankRecord> bankRecordsForFemale = bankRecordsByregion.stream()
					.filter(bankRecord -> bankRecord.getSex().equalsIgnoreCase("FEMALE")
							&& bankRecord.getMortgage().equalsIgnoreCase("YES")
							&& bankRecord.getSave_Act().equalsIgnoreCase("YES"));

			long fSize = bankRecordsForFemale.count();

			/* Creating a list of males with both a car and 1 child based on location */

			Stream<BankRecord> bankRecordsForMale = bankRecordsByregion.stream()
					.filter(bankRecord -> bankRecord.getSex().equalsIgnoreCase("MALE")
							&& bankRecord.getCar().equalsIgnoreCase("YES") && bankRecord.getChildren() == 1);

			long mSize = bankRecordsForMale.count();

			/**
			 * Manipulating the filtered data and storing in text file located in workspace
			 */
			DecimalFormat df = new DecimalFormat("#.##");
			writer.newLine();
			System.out.println("  \n" + doubleLine);
			writer.write(doubleLine);
			writer.newLine();
			System.out.println("Region : " + key);
			writer.write("Region : $" + key);
			writer.newLine();
			System.out.println("Max Income : $" + df.format(Collections.min(incomeList)));
			writer.write("Max Income : $" + df.format(Collections.min(incomeList)));
			writer.newLine();
			System.out.println("Min Income : $" + df.format(Collections.max(incomeList)));
			writer.write("Min Income : $" + df.format(Collections.max(incomeList)));
			writer.newLine();
			System.out.println("Average : $" + df.format(average));
			writer.write("Average : $" + df.format(average));
			writer.newLine();
			System.out.println("Count of Females with Mortgage and saving account : " + fSize);
			writer.write("Count of Females with Mortgage and saving account : " + fSize);
			writer.newLine();
			System.out.println("Count of Males with 1 children and Car : " + mSize);
			writer.write("Count of Males with 1 children and Car : " + mSize);
			writer.newLine();
			System.out.println("  \n" + doubleLine);
			writer.write(doubleLine);
			writer.newLine();

		}
		System.out.println("Filtered data has been saved Successfully !!!");
		writer.close();
	}
}
