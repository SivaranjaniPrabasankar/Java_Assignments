package records;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;

public class Records extends BankRecord {
	static FileWriter fw = null;

	public Records() {
		try {
			fw = new FileWriter("bankrecords.txt");

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		Records br = new Records();
		try {
			br.readData();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		// call functions to perform analytics
		LocationComp(); // analyze average income per loc
		// MaxMinComp(); //compare max and min incomes per loc
		// femsComp(); // analyze females w. mort/savings accounts per loc
		// malesComp(); // analyze male count w. car and 1 child per loc

		// *** close out file object ***//

		try {
			fw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private static void LocationComp() {

		Arrays.sort(robjs);
	
		// set up needed variables for region counts & incomes per location
		double townCt = 0, innerCt=0, suburbanCt=0,ruralCt=0,
				townIncSum = 0, innerIncSum=0, suburbanIncSum=0,ruralIncSum=0;

		for (int i = 0; i < robjs.length; i++)
			if (robjs[i].getRegion().equals("RURAL")) {
				ruralIncSum += robjs[i].getIncome();
				++ruralCt;
			} else if (robjs[i].getRegion().equals("INNER_CITY")) {
				innerIncSum += robjs[i].getIncome();
				++innerCt;
			} else if (robjs[i].getRegion().equals("TOWN")) {
				townIncSum += robjs[i].getIncome();
				++townCt;
			} else if (robjs[i].getRegion().equals("SUBURBAN")) {
				suburbanIncSum += robjs[i].getIncome();
				++suburbanCt;

			}
		// setup resulting averages to print to console and to file
		double ruralAvg = ruralIncSum / (ruralCt);

		System.out.printf("Avg inc. for rural region " + ruralAvg);

		try {
			fw.write("Avg inc. for rural region " + ruralAvg);
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
