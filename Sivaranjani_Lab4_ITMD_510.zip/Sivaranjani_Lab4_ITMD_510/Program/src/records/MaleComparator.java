package records;

public class MaleComparator {
	public int compare(BankRecord o1, BankRecord o2) {
		// TODO Auto-generated method stub
		int result = o1.getCar().compareTo(o2.getCar());
		return result;

	}
}
