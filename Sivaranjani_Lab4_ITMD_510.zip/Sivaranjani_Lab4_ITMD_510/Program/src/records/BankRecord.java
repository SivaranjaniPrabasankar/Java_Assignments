package records;

import java.io.*;
import java.util.*;

/**
 * @author Shiv
 *
 */
public class BankRecord {
	/**
	 * Declaring variables for formatting display
	 */
	static String doubleLine = "=================================================================================================================================================================";
	static String singleLine = "-----------------------------------------------------------------------------------------------------------------------------------------------------------------";
	static String dashLine = "|";
	public static List<BankRecord> dataList = new ArrayList<>();
	String cwd = System.getProperty("user.dir");
	static Scanner SCANNER = new Scanner(System.in);
	String fileName;
	/**
	 * Declaring variables to store each column of data from file
	 */
	private String id;
	private String sex;
	private String region, married, car, save_Act, current_Act, mortgage, pep;
	private int age, children;
	private double income;

	private static ArrayList<List<String>> array = new ArrayList<>();
	public static BankRecord robjs[] = new BankRecord[700];

	/**
	 * This is the method to read Banking Record from CSV file
	 * 
	 * @param br
	 * @param line
	 */
	public void readData() throws IOException {
		BufferedReader br = null;
		String line;
		System.out.println("Please Enter name of CSV File to load data. E.g: bank-detail");
		fileName = String.valueOf(SCANNER.next());
		/*
		 * Check if user has entered empty or invalid file name
		 */
		if (fileName.isEmpty()) {
			throw new IllegalArgumentException("File name shouldnot be empty");
		}
		while (fileName.contains(".") || fileName.contains("?") || fileName.contains("<") || fileName.contains(">")
				|| fileName.contains("/") || fileName.contains("\\") || fileName.contains("|") || fileName.contains(":")
				|| fileName.contains("\"") || fileName.contains("*")) {
			System.out.println("Enter valid CSV file without any extension");
			fileName = String.valueOf(SCANNER.next());
		}
		/*
		 * Try Catch block to check if user has entered file not present in respective
		 * location
		 */
		try {
			br = new BufferedReader(new FileReader(new File(fileName + ".csv")));
		} catch (Exception e) {
			System.out.println("The requested FILE NOT FOUND in : " + cwd);
			readData();
			return;
		}
		/*
		 * Clearing memory of array before entering data - To avoid array index out of
		 * bound
		 */
		if (br != null) {
			// Reading comma separated file
			while ((line = br.readLine()) != null) {
				array.add(Arrays.asList(line.split(",")));
			}
		}
		processData();

		System.out.println("Data loaded from the given file !!!....");
	}

	/**
	 * This is the method to process Banking Record and store in array list
	 * 
	 * @param idx
	 */
	public void processData() {
		/*
		 * Fetching data from CSV file and loading in array list
		 */
		for (List<String> rowData : array) {

			BankRecord bankRecord = new BankRecord();
			bankRecord.setId(rowData.get(0));
			bankRecord.setAge(Integer.parseInt(rowData.get(1)));
			bankRecord.setSex(rowData.get(2));
			bankRecord.setRegion(rowData.get(3));
			bankRecord.setIncome(Double.parseDouble(rowData.get(4)));
			bankRecord.setMarried(rowData.get(5));
			bankRecord.setChildren((Integer.parseInt(rowData.get(6))));
			bankRecord.setCar(rowData.get(7));
			bankRecord.setSave_Act(rowData.get(8));
			bankRecord.setCurrent_Act(rowData.get(9));
			bankRecord.setMortgage(rowData.get(10));
			bankRecord.setPep(rowData.get(11));
			dataList.add(bankRecord); // New, i will explain
		}

	}

	/**
	 * This is the method to display requested no.of. Banking Records from array
	 * list
	 * 
	 * @param printRows
	 */
	public void printData() {
		int printRows = 0;
		// Getting No.of rows to print from user
		while (printRows > array.size() || printRows < 1) {
			System.out.printf("Total.No.of.Rows in file : %d. \n", array.size());
			System.out.println("Please Enter valid No.of.rows to be printed");
			try {
				printRows = Integer.valueOf(SCANNER.next());
			} catch (NumberFormatException e) {
				System.out.println("Enter valid no.of.rows");
				printRows = 0;
			}
		}
		/*
		 * Printing data from CSV file in readable format
		 */
		System.out.println(doubleLine);
		System.out.print(dashLine);
		System.out.print(
				"ID \t\t AGE \t SEX   \t REGION	    INCOME \tMARRIAGE \tCHILDREN \tCAR \t SAVINGS\tCURRENT  \tMORTGAGE\tPEP	");
		System.out.println("  \t" + dashLine);
		System.out.println(doubleLine);
		int count = 0;
		for (BankRecord bankRecord : dataList) {
			System.out.print(dashLine);
			System.out.printf(
					"%s\t %d\t %s\t %-10.30s %.2f\t %s	\t  %d \t\t%-10.30s %-10.30s\t %-10.30s\t %-10.30s\t %-10.30s",
					bankRecord.getId(), bankRecord.getAge(), bankRecord.getSex(), bankRecord.getRegion(),
					bankRecord.getIncome(), bankRecord.getMarried(), bankRecord.getChildren(), bankRecord.getCar(),
					bankRecord.getSave_Act(), bankRecord.getCurrent_Act(), bankRecord.getMortgage(),
					bankRecord.getPep());
			System.out.println("  \t" + dashLine);
			System.out.println("\n" + singleLine);
			count++;
			if (count > printRows)
				break;
		}
		System.out.println(doubleLine);
	}

	/**
	 * Following methods to get/set data from/to the given file
	 */
// Getters and Setters for all fields
	public String getId() {
		return id;
	}

	public void setId(String string) {
		this.id = string;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String string) {
		this.sex = string;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getMarried() {
		return married;
	}

	public void setMarried(String married) {
		this.married = married;
	}

	public String getCar() {
		return car;
	}

	public void setCar(String car) {
		this.car = car;
	}

	public String getSave_Act() {
		return save_Act;
	}

	public void setSave_Act(String save_Act) {
		this.save_Act = save_Act;
	}

	public String getCurrent_Act() {
		return current_Act;
	}

	public void setCurrent_Act(String current_Act) {
		this.current_Act = current_Act;
	}

	public String getMortgage() {
		return mortgage;
	}

	public void setMortgage(String mortgage) {
		this.mortgage = mortgage;
	}

	public String getPep() {
		return pep;
	}

	public void setPep(String pep) {
		this.pep = pep;
	}

	public int getChildren() {
		return children;
	}

	public void setChildren(int children) {
		this.children = children;
	}

	public double getIncome() {
		return income;
	}

	public void setIncome(double income) {
		this.income = income;
	}

	public List<BankRecord> getCheck() {
		return dataList;
	}

	public void setCheck(List<BankRecord> check) {
		this.dataList = check;
	}

	public ArrayList<List<String>> getArray() {
		return array;
	}

	public void setArray(ArrayList<List<String>> array) {
		this.array = array;
	}

	public BankRecord[] getRobjs() {
		return robjs;
	}

	public void setRobjs(BankRecord[] robjs) {
		this.robjs = robjs;
	}

	public int compare(BankRecord ob1, BankRecord ob2) {
		// TODO Auto-generated method stub
		return 0;
	}

	

}
