package views;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

public class ConsoleView {
	public void normalView(ResultSet rs) {
		// instantiate vector objects to hold column/row data for JTable
		try {
			ResultSetMetaData metaData = rs.getMetaData();
			int columns = metaData.getColumnCount();
			// get column names from table!

			String cols = "";
			System.out.println(
					"========================================================================");
			for (int i = 1; i <= columns; i++) {

				cols = metaData.getColumnName(i);
				System.out.print("\t" + cols+"\t");
			}
			// get row data from table!
			while (rs.next()) {
				System.out.println();
				for (int i = 1; i <= columns; i++) {
					System.out.print("\t " + rs.getObject(i));
				}
				System.out.println();
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

}
