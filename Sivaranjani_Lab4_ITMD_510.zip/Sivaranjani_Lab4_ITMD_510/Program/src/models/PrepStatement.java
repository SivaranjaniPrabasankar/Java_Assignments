package models;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public interface PrepStatement {


		PreparedStatement executeQuery(String string ) throws SQLException;
		
	}


