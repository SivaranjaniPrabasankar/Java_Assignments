package models;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import controller.LoanProcessing;
import records.BankRecord;
import views.ConsoleView;
import views.LoanView;

public class DaoModel implements PrepStatement {
	DBConnect conn = null;
	Statement stmt = null;

	// constructor
	public DaoModel() { // create db object instance
		conn = new DBConnect();
		System.out.println("Connecting to database to create Table...");
		System.out.println("Connected database successfully...");
	}

	public void createTable() {
		try {
DaoModel dm=new DaoModel();
LoanProcessing lp=new LoanProcessing();
			stmt = conn.connect().createStatement();
			String sql = "CREATE TABLE SP_ITMD510_LAB4" + "(pid INTEGER not NULL AUTO_INCREMENT, "
					+ " id VARCHAR(10), " + " income numeric(8,2), " + " pep VARCHAR(10), " + " PRIMARY KEY ( pid ))";
			stmt.executeUpdate(sql);
			System.out.println("Created new table in given database...");
			System.out.println("inserting Records from file !!!!.....");
			dm.insertRecords(lp.dataList);
			conn.connect().close();
		} catch (SQLException se) {
			System.out.println("SORRY!!! Table already Exists.");
		}
	}

	public void insertRecords(List<BankRecord> dataList) {
		try {
			// Execute a query
			int count = 0;
			stmt = conn.connect().createStatement();
			String sql = null, pep, id;

			double income;
			// Include all object data to the database table
			for (BankRecord bankRecord : dataList) {

				id = bankRecord.getId();
				pep = bankRecord.getPep();
				income = bankRecord.getIncome();
				System.out.println("ID : " + bankRecord.getId());
				sql = "INSERT INTO SP_ITMD510_LAB4 (id,income,pep) " + "VALUES (' " + id + " ', ' " + income
						+ " ', ' " + pep + " ' )";
				stmt.executeUpdate(sql);
				System.out.println("Inerted records : " + count++);

			}
			System.out.println("Records inserted Succesfully from file !!!!.....");

			conn.connect().close();
		} catch (SQLException se) {
			se.printStackTrace();
		}
	}

	public void executeQuery(String id, Double inc, String pep) throws SQLException {
		String sql = "insert into SP_ITMD510_LAB4 (id,income,pep) values(?,?,?)";
		PreparedStatement stmt = conn.connect().prepareStatement(sql);
		stmt.setString(1, id);
		stmt.setDouble(2, inc);
		stmt.setString(3, pep);
		stmt.executeUpdate();
		stmt.close();
	}

	public ResultSet retrieveRecords() throws SQLException {

		ResultSet rs = null;
		stmt = conn.connect().createStatement();
		String sql = "SELECT * from SP_ITMD510_LAB4";
		rs = stmt.executeQuery(sql);
		conn.connect().close();
		return rs;
	}

	public ResultSet retrievePremiumRecords() throws SQLException {
		ResultSet rs = null;
		stmt = conn.connect().createStatement();
		String sql = "SELECT * from SP_ITMD510_LAB4 ORDER BY pep DESC ";
		rs = stmt.executeQuery(sql);
		conn.connect().close();
		return rs;
	}

	public PreparedStatement executeQuery(String string) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

}
