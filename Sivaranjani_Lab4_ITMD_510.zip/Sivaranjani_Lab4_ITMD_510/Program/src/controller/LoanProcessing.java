package controller;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLSyntaxErrorException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Scanner;

import models.DaoModel;
import records.BankRecord;
import views.LoanView;

public class LoanProcessing extends BankRecord {

	public static void main(String[] args) {
		BankRecord br = new BankRecord();
		Scanner SCANNER = new Scanner(System.in);
		DaoModel dm = new DaoModel();
		LoanView lv = new LoanView();

		double income = 0;
		String pep = "0", id = "";

		System.out.println("-----------------------------------------");
		System.out.println("	Welcome to Student Banking");
		System.out.println("-----------------------------------------");
		System.out.println("Reading Data from File");
		try {
			br.readData();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			System.out.println("Failed in loading data file");
		}
		
			dm.createTable();
		
	

	
		System.out.println("Enter details to insert your records!!!..");
		do {
			System.out.println("Please enter your ID");
			id = SCANNER.next();
		} while (id.isEmpty() || id.contains(".") || id.contains("?") || id.contains("<") || id.contains(">")
				|| id.contains("/") || id.contains("\\") || id.contains("|") || id.contains(":") || id.contains("\"")
				|| id.contains("*"));

		do {
			try {
				System.out.println("Please enter the income in USD to update in your account " + id);
				income = Double.valueOf(SCANNER.next());

			} catch (Exception e) {
				System.out.println("You have entered invalid income details . ");
			}
		} while (income <= 0);
		System.out.println("Please re-enter 1 to become previledge customer" + id);
		pep = SCANNER.next();
		if (pep.equals("1"))
			try {
				dm.executeQuery(id, income, "YES");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		else
			try {
				dm.executeQuery(id, income, "NO");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		System.out.println("========================================================================");

		System.out.println("All customer Records");
		ResultSet rs1 = null;
		try {
			rs1 = dm.retrieveRecords();
		} catch (SQLException e3) {
			// TODO Auto-generated catch block
			e3.printStackTrace();
		}
		lv.runView(rs1);

		System.out.println("========================================================================");

		System.out.println("Hierarchical customer Records");
		ResultSet rs2 = null;
		try {
			rs2 = dm.retrievePremiumRecords();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		lv.runView(rs2);
		System.out.println("========================================================================");

		System.out.println("Thank You for using our Application");

		String timeStamp = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime());
		System.out.println("Date and Time :" + timeStamp + "\nProgrammed by Sivaranjani A20436206 \n");
		System.out.println("========================================================================");
	}
}
